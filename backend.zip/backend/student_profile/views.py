from django.shortcuts import render
from django.views.generic import TemplateView
from student_profile.forms import DocumentForm
from student_profile.models import Document
from io import StringIO, BytesIO

from django.template.defaulttags import register

from PIL import Image
import hashlib
import django
import os
class allStudents(TemplateView):
    def get(self, request, **kwargs):
        data=Document.objects.all()
        new=[]
        for i in list(range(0,len(data)-3,3)):
            new.append(data[i:i+3])

        args={"data":data,"set":new,"remaining": data[len(data)-int(len(data)%3):len(data)] }
        print(args)
        return render(request, 'students_profile.html', args)

def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            
    else:
        form = DocumentForm()
    return render(request, 'model_form_upload.html', {
        'form': form
    })


@register.filter
def get_range(value):
    return range(value)

@register.filter
def get_path(pt):
    print(pt)
    pt=str(pt)
    pt=pt.split("static")
    return pt[-1]

@register.filter
def id_extract(email):
    return email.split("@")[0]
