from django.apps import AppConfig


class StudentProfileConfig(AppConfig):
    name = 'student_profile'
